import React from "react";

const Footer = () => (
    // Footer component
    <footer>
    	<div className="footer"> 
    		<h6> DWS © 2018 </h6>
    	</div>
    </footer>
);

export default Footer;